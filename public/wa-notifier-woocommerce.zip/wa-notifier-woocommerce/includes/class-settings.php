<?php
if (!defined('ABSPATH')) exit;

class WANW_Settings {
    const OPT_API_BASE  = 'wanw_api_base';
    const OPT_LICENSE   = 'wanw_license_key';
    const OPT_BRAND     = 'wanw_brand';
    const OPT_DEVICE    = 'wanw_device_id';
    const OPT_WOO       = 'wanw_woo_config';
    const OPT_ADMIN     = 'wanw_admin_config';
    const OPT_COMPLETE  = 'wanw_setup_complete';
    const OPT_SAFETY    = 'wanw_safety';

    public static function api_base() {
        return rtrim(get_option(self::OPT_API_BASE, WANW_DEFAULT_API_BASE), '/');
    }
    public static function license() { return get_option(self::OPT_LICENSE, ''); }
    public static function brand()   { return get_option(self::OPT_BRAND, []); }
    public static function device()  { return get_option(self::OPT_DEVICE, ''); }

    /** Default Bangla templates per status, with call-back line on pending/processing. */
    public static function default_customer_templates() {
        $sales_line = ' আমাদের সেলস টিম কিছুক্ষণের মধ্যে আপনাকে কল করবে।';
        return [
            'pending'    => "প্রিয় {first_name}, আপনার অর্ডার #{order_id} আমরা পেয়েছি। মোট: {total}।" . $sales_line,
            'processing' => "প্রিয় {first_name}, আপনার অর্ডার #{order_id} প্রক্রিয়াধীন আছে। মোট: {total}।" . $sales_line,
            'on-hold'    => "প্রিয় {first_name}, আপনার অর্ডার #{order_id} আপাতত হোল্ডে রাখা হয়েছে। মোট: {total}।",
            'completed'  => "প্রিয় {first_name}, আপনার অর্ডার #{order_id} সফলভাবে ডেলিভারি সম্পন্ন হয়েছে। আমাদের সাথে কেনাকাটার জন্য ধন্যবাদ!",
            'cancelled'  => "প্রিয় {first_name}, আপনার অর্ডার #{order_id} বাতিল করা হয়েছে।",
            'refunded'   => "প্রিয় {first_name}, আপনার অর্ডার #{order_id} এর রিফান্ড সম্পন্ন হয়েছে। মোট: {total}।",
            'failed'     => "প্রিয় {first_name}, আপনার অর্ডার #{order_id} প্রসেস করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।",
        ];
    }

    public static function default_admin_templates() {
        return [
            'pending'    => "নতুন অর্ডার #{order_id} এসেছে। গ্রাহক: {first_name} {last_name}। মোট: {total}।",
            'processing' => "অর্ডার #{order_id} প্রসেসিংয়ে। গ্রাহক: {first_name} {last_name}। মোট: {total}।",
            'on-hold'    => "অর্ডার #{order_id} হোল্ডে রাখা হয়েছে। গ্রাহক: {first_name} {last_name}।",
            'completed'  => "অর্ডার #{order_id} সম্পন্ন হয়েছে। গ্রাহক: {first_name} {last_name}। মোট: {total}।",
            'cancelled'  => "অর্ডার #{order_id} বাতিল হয়েছে। গ্রাহক: {first_name} {last_name}।",
            'refunded'   => "অর্ডার #{order_id} রিফান্ড করা হয়েছে। মোট: {total}।",
            'failed'     => "অর্ডার #{order_id} প্রসেস ব্যর্থ। গ্রাহক: {first_name} {last_name}।",
        ];
    }

    public static function woo_config() {
        $tpls = self::default_customer_templates();
        $defaults = [];
        foreach (self::woo_statuses() as $key => $label) {
            $defaults[$key] = [
                'enabled'  => false,
                'template' => $tpls[$key] ?? "প্রিয় {first_name}, আপনার অর্ডার #{order_id} এর স্ট্যাটাস: {status}।",
                'delay'    => 0, // seconds
            ];
        }
        $stored = get_option(self::OPT_WOO, []);
        return array_replace_recursive($defaults, is_array($stored) ? $stored : []);
    }

    public static function admin_config() {
        $tpls = self::default_admin_templates();
        $defaults = [
            'phone'    => '',
            'statuses' => [],
        ];
        foreach (self::woo_statuses() as $key => $label) {
            $defaults['statuses'][$key] = [
                'enabled'  => false,
                'template' => $tpls[$key] ?? "অর্ডার #{order_id} স্ট্যাটাস: {status}।",
                'delay'    => 0,
            ];
        }
        $stored = get_option(self::OPT_ADMIN, []);
        return array_replace_recursive($defaults, is_array($stored) ? $stored : []);
    }


    public static function safety() {
        $defaults = [
            'enabled'            => true,
            'min_delay'          => 5,
            'jitter_max'         => 10,
            'recipient_cooldown' => 60,
        ];
        $stored = get_option(self::OPT_SAFETY, []);
        return array_replace($defaults, is_array($stored) ? $stored : []);
    }

    public static function woo_statuses() {
        return [
            'pending'    => 'Pending payment',
            'processing' => 'Processing',
            'on-hold'    => 'On hold',
            'completed'  => 'Completed',
            'cancelled'  => 'Cancelled',
            'refunded'   => 'Refunded',
            'failed'     => 'Failed',
        ];
    }
}
