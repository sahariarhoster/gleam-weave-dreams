<?php
if (!defined('ABSPATH')) exit;
if (!current_user_can('manage_options')) return;

$msg = null; $tone = 'success';
if ($_SERVER['REQUEST_METHOD']==='POST' && check_admin_referer('wanw_lic')) {
    if (isset($_POST['reset'])) {
        delete_option(WANW_Settings::OPT_LICENSE);
        delete_option(WANW_Settings::OPT_BRAND);
        delete_option(WANW_Settings::OPT_DEVICE);
        delete_option(WANW_Settings::OPT_COMPLETE);
        $msg = 'License cleared. Re-run the setup wizard.';
    } else {
        $key = sanitize_text_field($_POST['license_key'] ?? '');
        delete_option(WANW_Settings::OPT_API_BASE);
        $res = WANW_Api::activate($key, home_url());
        if (!empty($res['ok'])) {
            update_option(WANW_Settings::OPT_LICENSE, $key);
            update_option(WANW_Settings::OPT_BRAND, ['id'=>$res['brand_id']??'','name'=>$res['brand_name']??'']);
            $msg = 'License updated successfully.';
        } else {
            $msg = $res['error'] ?? 'Activation failed.';
            $tone = 'error';
        }
    }
}
?>
<div class="wrap wanw-dash">
    <div class="wanw-topbar"><div><h1>License Settings</h1><p class="wanw-sub">Manage the license key powering this WordPress installation.</p></div></div>
    <?php if ($msg): ?><div class="notice notice-<?php echo esc_attr($tone); ?>"><p><?php echo esc_html($msg); ?></p></div><?php endif; ?>
    <div class="wanw-card">
        <form method="post">
            <?php wp_nonce_field('wanw_lic'); ?>
            <p><label><strong>License Key</strong><br><input type="text" name="license_key" class="regular-text" value="<?php echo esc_attr(WANW_Settings::license()); ?>" placeholder="HS-XXXX-XXXX-XXXX"></label></p>
            <p>
                <button class="button button-primary">Activate</button>
                <button class="button" name="reset" value="1" onclick="return confirm('Clear license?');">Clear License</button>
            </p>
        </form>
    </div>
</div>
