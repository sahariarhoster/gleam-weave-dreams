<?php
if (!defined('ABSPATH')) exit;
if (!current_user_can('manage_options')) return;

$saved = false;
if ($_SERVER['REQUEST_METHOD']==='POST' && check_admin_referer('wanw_woo')) {
    $cfg = [];
    foreach (WANW_Settings::woo_statuses() as $k => $_) {
        $cfg[$k] = [
            'enabled'  => !empty($_POST['enabled'][$k]),
            'template' => wp_kses_post($_POST['template'][$k] ?? ''),
            'delay'    => max(0, intval($_POST['delay'][$k] ?? 0)),
        ];
    }
    update_option(WANW_Settings::OPT_WOO, $cfg);
    $saved = true;
}
$woo = WANW_Settings::woo_config();
?>
<div class="wrap wanw-dash">
    <div class="wanw-topbar"><div><h1>Customer Notifications</h1><p class="wanw-sub">Configure WhatsApp messages sent to customers on WooCommerce order events. Set a per-status send delay (in seconds) so notifications don't fire instantly.</p></div></div>
    <?php if ($saved): ?><div class="notice notice-success"><p>Templates saved.</p></div><?php endif; ?>
    <div class="wanw-card">
        <h2>Available Shortcodes</h2>
        <p class="wanw-muted"><?php echo esc_html(implode(' · ', WANW_Shortcodes::available())); ?></p>
    </div>
    <form method="post">
        <?php wp_nonce_field('wanw_woo'); ?>
        <div class="wanw-card">
            <h2>Message Templates</h2>
            <table class="widefat striped">
                <thead><tr><th style="width:50px;">On</th><th style="width:160px;">Order Status</th><th>Customer Message</th><th style="width:120px;">Delay (sec)</th></tr></thead>
                <tbody>
                <?php foreach (WANW_Settings::woo_statuses() as $k => $label): ?>
                    <tr>
                        <td><input type="checkbox" name="enabled[<?php echo esc_attr($k); ?>]" <?php checked(!empty($woo[$k]['enabled'])); ?>></td>
                        <td><strong><?php echo esc_html($label); ?></strong></td>
                        <td><textarea name="template[<?php echo esc_attr($k); ?>]" rows="2" style="width:100%;"><?php echo esc_textarea($woo[$k]['template']); ?></textarea></td>
                        <td><input type="number" min="0" max="86400" step="1" name="delay[<?php echo esc_attr($k); ?>]" value="<?php echo intval($woo[$k]['delay'] ?? 0); ?>" style="width:100%;"></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <p class="wanw-muted" style="margin-top:8px;">Delay = how many seconds to wait after the status change before sending. <code>0</code> = send immediately. Uses WP-Cron, so make sure your site receives regular traffic or a real cron is configured.</p>
            <p style="margin-top:14px;"><button class="button button-primary">Save Templates</button></p>
        </div>
    </form>
</div>
