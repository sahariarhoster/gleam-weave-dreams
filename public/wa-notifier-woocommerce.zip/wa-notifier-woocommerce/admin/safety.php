<?php
if (!defined('ABSPATH')) exit;
if (!current_user_can('manage_options')) return;

$saved = false;
if ($_SERVER['REQUEST_METHOD']==='POST' && check_admin_referer('wanw_safety')) {
    $cfg = [
        'enabled'           => !empty($_POST['enabled']),
        'min_delay'         => max(0, min(3600, intval($_POST['min_delay'] ?? 5))),
        'jitter_max'        => max(0, min(3600, intval($_POST['jitter_max'] ?? 10))),
        'recipient_cooldown'=> max(0, min(86400, intval($_POST['recipient_cooldown'] ?? 60))),
    ];
    update_option(WANW_Settings::OPT_SAFETY, $cfg);
    $saved = true;
}
$s = WANW_Settings::safety();
?>
<div class="wrap wanw-dash">
    <div class="wanw-topbar"><div>
        <h1>🛡️ Safety &amp; Ban Protection</h1>
        <p class="wanw-sub">Reduce the chance of your WhatsApp number being flagged. These limits apply on top of any per-status delay you've configured.</p>
    </div></div>
    <?php if ($saved): ?><div class="notice notice-success"><p>Safety settings saved.</p></div><?php endif; ?>

    <form method="post">
        <?php wp_nonce_field('wanw_safety'); ?>
        <div class="wanw-card">
            <table class="form-table">
                <tr>
                    <th><label>Enable safety delays</label></th>
                    <td>
                        <label><input type="checkbox" name="enabled" <?php checked(!empty($s['enabled'])); ?>> Apply minimum delay and random jitter to every message</label>
                        <p class="description">Strongly recommended. Disable only for testing.</p>
                    </td>
                </tr>
                <tr>
                    <th><label>Minimum delay (seconds)</label></th>
                    <td>
                        <input type="number" min="0" max="3600" name="min_delay" value="<?php echo intval($s['min_delay']); ?>" class="small-text">
                        <p class="description">Every notification waits at least this long before sending. Default: 5s.</p>
                    </td>
                </tr>
                <tr>
                    <th><label>Random jitter (seconds)</label></th>
                    <td>
                        <input type="number" min="0" max="3600" name="jitter_max" value="<?php echo intval($s['jitter_max']); ?>" class="small-text">
                        <p class="description">A random 0–N seconds added on top of the minimum delay so bursts don't look bot-like. Default: 10s.</p>
                    </td>
                </tr>
                <tr>
                    <th><label>Per-recipient cooldown (seconds)</label></th>
                    <td>
                        <input type="number" min="0" max="86400" name="recipient_cooldown" value="<?php echo intval($s['recipient_cooldown']); ?>" class="small-text">
                        <p class="description">Skip sending to the same phone number again within this window. Default: 60s.</p>
                    </td>
                </tr>
            </table>
            <p><button class="button button-primary">Save Safety Settings</button></p>
        </div>

        <div class="wanw-card">
            <h2>How it works</h2>
            <ul style="list-style:disc;margin-left:20px;">
                <li>Effective delay = <code>max(per-status delay, minimum delay) + random(0, jitter)</code>.</li>
                <li>Per-recipient cooldown is enforced locally before the message hits our server.</li>
                <li>Our server also enforces dedupe and brand-wide rate limits as a second safety net.</li>
            </ul>
        </div>
    </form>
</div>
