<?php
if (!defined('ABSPATH')) exit;
if (!current_user_can('manage_options')) return;

$saved = false;
if ($_SERVER['REQUEST_METHOD']==='POST' && check_admin_referer('wanw_woo')) {
    $cfg = [];
    foreach (WANW_Settings::woo_statuses() as $k => $_) {
        $cfg[$k] = [
            'enabled'  => !empty($_POST['enabled'][$k]),
            'template' => wp_kses_post($_POST['template'][$k] ?? ''),
        ];
    }
    update_option(WANW_Settings::OPT_WOO, $cfg);
    $saved = true;
}
$woo = WANW_Settings::woo_config();
?>
<div class="wrap wanw-dash">
    <div class="wanw-topbar"><div><h1>Customer Notifications</h1><p class="wanw-sub">Configure WhatsApp messages sent to customers on WooCommerce order events.</p></div></div>
    <?php if ($saved): ?><div class="notice notice-success"><p>Templates saved.</p></div><?php endif; ?>
    <div class="wanw-card">
        <h2>Available Shortcodes</h2>
        <p class="wanw-muted"><?php echo esc_html(implode(' · ', WANW_Shortcodes::available())); ?></p>
    </div>
    <form method="post">
        <?php wp_nonce_field('wanw_woo'); ?>
        <div class="wanw-card">
            <h2>Message Templates</h2>
            <table class="widefat striped">
                <thead><tr><th style="width:60px;">On</th><th style="width:180px;">Order Status</th><th>Customer Message</th></tr></thead>
                <tbody>
                <?php foreach (WANW_Settings::woo_statuses() as $k => $label): ?>
                    <tr>
                        <td><input type="checkbox" name="enabled[<?php echo esc_attr($k); ?>]" <?php checked(!empty($woo[$k]['enabled'])); ?>></td>
                        <td><strong><?php echo esc_html($label); ?></strong></td>
                        <td><textarea name="template[<?php echo esc_attr($k); ?>]" rows="2" style="width:100%;"><?php echo esc_textarea($woo[$k]['template']); ?></textarea></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <p style="margin-top:14px;"><button class="button button-primary">Save Templates</button></p>
        </div>
    </form>
</div>
