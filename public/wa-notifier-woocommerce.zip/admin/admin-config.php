<?php
if (!defined('ABSPATH')) exit;
if (!current_user_can('manage_options')) return;

$saved = false;
if ($_SERVER['REQUEST_METHOD']==='POST' && check_admin_referer('wanw_admin')) {
    $ac = WANW_Settings::admin_config();
    $ac['phone'] = sanitize_text_field($_POST['admin_phone'] ?? '');
    foreach (WANW_Settings::woo_statuses() as $k => $_) {
        $ac['statuses'][$k] = [
            'enabled'  => !empty($_POST['enabled'][$k]),
            'template' => wp_kses_post($_POST['template'][$k] ?? ''),
        ];
    }
    update_option(WANW_Settings::OPT_ADMIN, $ac);
    $saved = true;
}
$ac = WANW_Settings::admin_config();
?>
<div class="wrap wanw-dash">
    <div class="wanw-topbar"><div><h1>Admin Notifications</h1><p class="wanw-sub">Get notified on WhatsApp when order events happen in your store.</p></div></div>
    <?php if ($saved): ?><div class="notice notice-success"><p>Settings saved.</p></div><?php endif; ?>
    <form method="post">
        <?php wp_nonce_field('wanw_admin'); ?>
        <div class="wanw-card">
            <h2>Admin Number</h2>
            <p><label><strong>Admin WhatsApp Number</strong><br>
                <input type="text" name="admin_phone" class="regular-text" value="<?php echo esc_attr($ac['phone']); ?>" placeholder="+8801XXXXXXXXX">
            </label></p>
        </div>
        <div class="wanw-card">
            <h2>Notification Triggers</h2>
            <table class="widefat striped">
                <thead><tr><th style="width:60px;">On</th><th style="width:180px;">Order Status</th><th>Admin Message</th></tr></thead>
                <tbody>
                <?php foreach (WANW_Settings::woo_statuses() as $k => $label): ?>
                    <tr>
                        <td><input type="checkbox" name="enabled[<?php echo esc_attr($k); ?>]" <?php checked(!empty($ac['statuses'][$k]['enabled'])); ?>></td>
                        <td><strong><?php echo esc_html($label); ?></strong></td>
                        <td><textarea name="template[<?php echo esc_attr($k); ?>]" rows="2" style="width:100%;"><?php echo esc_textarea($ac['statuses'][$k]['template']); ?></textarea></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <p style="margin-top:14px;"><button class="button button-primary">Save Settings</button></p>
        </div>
    </form>
</div>
