<?php
if (!defined('ABSPATH')) exit;
$brand = WANW_Settings::brand();
$lic = WANW_Settings::license();

// Cached, non-blocking lookups so the dashboard renders fast even if the API is slow.
$hb = null; $stats = null; $remote = null;
if ($lic) {
    $hb = get_transient('wanw_hb');
    if ($hb === false) { $hb = WANW_Api::heartbeat($lic); set_transient('wanw_hb', $hb, 60); }
    $stats = get_transient('wanw_stats');
    if ($stats === false) { $stats = WANW_Api::stats($lic); set_transient('wanw_stats', $stats, 60); }
    $remote = WANW_Updater::fetch_remote(!empty($_GET['wanw_update_checked']));
}
$has_update = is_array($remote) && !empty($remote['version']) && version_compare(WANW_VERSION, $remote['version'], '<');
$totals = !empty($stats['ok']) ? $stats['totals'] : ['sent'=>0,'failed'=>0,'today'=>0,'contacts'=>0];
$series = !empty($stats['ok']) ? $stats['series'] : [];
$max = 1;
foreach ($series as $d) { $max = max($max, intval($d['sent']) + intval($d['failed'])); }
?>
<div class="wrap wanw-dash">
    <?php if (!$lic): ?>
        <div class="wanw-hero">
            <h1>👋 Welcome to WA Notifier</h1>
            <p>Activate your license to start sending WhatsApp notifications from WooCommerce.</p>
            <a class="wanw-btn wanw-btn-primary" href="<?php echo esc_url(admin_url('admin.php?page=wanw-wizard')); ?>">Start Setup Wizard →</a>
        </div>
    <?php else: ?>
        <div class="wanw-topbar">
            <div>
                <h1>Dashboard</h1>
                <p class="wanw-sub">
                    Brand: <strong><?php echo esc_html($brand['name'] ?? '—'); ?></strong>
                    · Version <strong><?php echo esc_html(WANW_VERSION); ?></strong>
                    · Status:
                    <?php if (!empty($hb['ok'])): ?>
                        <span class="wanw-pill wanw-pill-ok">● Connected</span>
                    <?php else: ?>
                        <span class="wanw-pill wanw-pill-bad">● Offline</span>
                    <?php endif; ?>
                </p>
            </div>
            <div class="wanw-actions">
                <a class="wanw-btn" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=wanw_check_update'), 'wanw_check_update')); ?>">Check Update</a>
                <a class="wanw-btn" href="<?php echo esc_url(admin_url('admin.php?page=wanw-test')); ?>">Send Test</a>
                <a class="wanw-btn" href="<?php echo esc_url(admin_url('admin.php?page=wanw-wizard')); ?>" title="Re-run the setup wizard. Your existing license, device, and templates are preserved — change only what you need.">↻ Relaunch Setup Wizard</a>
                <a class="wanw-btn wanw-btn-primary" href="<?php echo esc_url(admin_url('admin.php?page=wanw-woo')); ?>">Templates</a>
            </div>
        </div>

        <?php if ($has_update): ?>
        <div class="wanw-update-card wanw-update-ready">
            <div>
                <div class="wanw-stat-label">Plugin Update</div>
                <strong>Version <?php echo esc_html($remote['version']); ?> is ready</strong>
                <p>Install the newest dashboard, updater, and automation improvements.</p>
            </div>
            <a class="wanw-btn wanw-btn-primary" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=wanw_start_update'), 'wanw_start_update')); ?>">Update Now</a>
        </div>
        <?php endif; ?>

        <div class="wanw-stat-grid">
            <div class="wanw-stat"><div class="wanw-stat-label">Today</div><div class="wanw-stat-value"><?php echo intval($totals['today']); ?></div><div class="wanw-stat-meta">messages sent today</div></div>
            <div class="wanw-stat"><div class="wanw-stat-label">7-day Sent</div><div class="wanw-stat-value"><?php echo intval($totals['sent']); ?></div><div class="wanw-stat-meta">successful deliveries</div></div>
            <div class="wanw-stat"><div class="wanw-stat-label">7-day Failed</div><div class="wanw-stat-value wanw-bad"><?php echo intval($totals['failed']); ?></div><div class="wanw-stat-meta">errors / retries</div></div>
            <div class="wanw-stat"><div class="wanw-stat-label">WordPress Contacts</div><div class="wanw-stat-value"><?php echo intval($totals['contacts']); ?></div><div class="wanw-stat-meta">in WordPress group</div></div>
        </div>

        <div class="wanw-card">
            <div class="wanw-card-head">
                <h2>Last 7 days</h2>
                <span class="wanw-muted">sent vs failed</span>
            </div>
            <?php if (empty($series)): ?>
                <p class="wanw-muted">No activity yet. Once your store sends notifications they'll appear here.</p>
            <?php else: ?>
            <div class="wanw-chart">
                <?php foreach ($series as $d): $sent = intval($d['sent']); $failed = intval($d['failed']); $h1 = $sent ? max(6, round($sent * 140 / $max)) : 2; $h2 = $failed ? max(4, round($failed * 140 / $max)) : 0; ?>
                    <div class="wanw-col">
                        <div class="wanw-bar-wrap">
                            <?php if ($failed): ?><div class="wanw-bar wanw-bar-fail" style="height:<?php echo $h2; ?>px" title="Failed: <?php echo $failed; ?>"></div><?php endif; ?>
                            <div class="wanw-bar wanw-bar-ok" style="height:<?php echo $h1; ?>px" title="Sent: <?php echo $sent; ?>"></div>
                        </div>
                        <span class="wanw-col-label"><?php echo esc_html(date('D', strtotime($d['date']))); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <div class="wanw-grid-2">
            <div class="wanw-card">
                <h2>Connection</h2>
                <table class="wanw-kv">
                    <tr><th>License</th><td><code><?php echo esc_html($lic); ?></code></td></tr>
                    <tr><th>Device</th><td><?php echo esc_html(WANW_Settings::device() ?: '— not selected —'); ?></td></tr>
                </table>
                <p>
                    <a class="wanw-btn" href="<?php echo esc_url(admin_url('admin.php?page=wanw-license')); ?>">Change License</a>
                </p>
            </div>

            <div class="wanw-card">
                <h2>Quick links</h2>
                <ul class="wanw-links">
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=wanw-woo')); ?>">📦 Customer notification templates</a></li>
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=wanw-admin')); ?>">🔔 Admin alerts</a></li>
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=wanw-test')); ?>">✉️ Send a test message</a></li>
                    <li><a href="<?php echo esc_url(admin_url('admin.php?page=wanw-license')); ?>">🔑 License settings</a></li>
                </ul>
            </div>
        </div>
    <?php endif; ?>
</div>
