<?php
if (!defined('ABSPATH')) exit;

class WANW_Woo_Hooks {
    const CRON_HOOK = 'wanw_delayed_send';

    public static function init() {
        add_action('woocommerce_order_status_changed', [__CLASS__, 'on_status_change'], 10, 4);
        add_action(self::CRON_HOOK, [__CLASS__, 'dispatch_scheduled'], 10, 4);
    }

    public static function on_status_change($order_id, $from, $to, $order) {
        if (!WANW_Settings::license() || !WANW_Settings::device()) return;
        if (!$order instanceof WC_Order) {
            $order = wc_get_order($order_id);
            if (!$order) return;
        }

        $woo   = WANW_Settings::woo_config();
        $admin = WANW_Settings::admin_config();
        $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());

        // Customer
        if (!empty($woo[$to]['enabled'])) {
            $phone = $order->get_billing_phone();
            if ($phone) {
                $delay = max(0, intval($woo[$to]['delay'] ?? 0));
                self::queue($delay, 'customer', $order_id, $to);
            }
        }

        // Admin
        if (!empty($admin['statuses'][$to]['enabled']) && !empty($admin['phone'])) {
            $delay = max(0, intval($admin['statuses'][$to]['delay'] ?? 0));
            self::queue($delay, 'admin', $order_id, $to);
        }
    }

    protected static function queue($delay, $type, $order_id, $status) {
        $safety = WANW_Settings::safety();
        if (!empty($safety['enabled'])) {
            $delay = max(intval($delay), intval($safety['min_delay']));
            $jitter = intval($safety['jitter_max']);
            if ($jitter > 0) $delay += wp_rand(0, $jitter);
        }
        if ($delay <= 0) {
            self::dispatch_scheduled($type, $order_id, $status, time());
            return;
        }
        wp_schedule_single_event(time() + $delay, self::CRON_HOOK, [$type, $order_id, $status, time()]);
    }

    protected static function cooldown_hit($phone) {
        $safety = WANW_Settings::safety();
        if (empty($safety['enabled'])) return false;
        $cool = intval($safety['recipient_cooldown']);
        if ($cool <= 0) return false;
        $key = 'wanw_cd_' . md5($phone);
        if (get_transient($key)) return true;
        set_transient($key, 1, $cool);
        return false;
    }

    public static function dispatch_scheduled($type, $order_id, $status, $queued_at = 0) {
        $order = wc_get_order($order_id);
        if (!$order) return;
        // If order status changed away from the trigger status, skip (avoid stale follow-ups).
        if ($order->get_status() !== $status) return;

        $license = WANW_Settings::license();
        if (!$license) return;
        $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());

        if ($type === 'customer') {
            $woo = WANW_Settings::woo_config();
            if (empty($woo[$status]['enabled'])) return;
            $phone = $order->get_billing_phone();
            if (!$phone) return;
            if (self::cooldown_hit($phone)) return;
            $msg = WANW_Shortcodes::render($woo[$status]['template'], $order);
            WANW_Api::send($license, $phone, $msg, $customer_name);
        } elseif ($type === 'admin') {
            $admin = WANW_Settings::admin_config();
            if (empty($admin['statuses'][$status]['enabled']) || empty($admin['phone'])) return;
            if (self::cooldown_hit($admin['phone'])) return;
            $msg = WANW_Shortcodes::render($admin['statuses'][$status]['template'], $order);
            WANW_Api::send($license, $admin['phone'], $msg, 'Admin');
        }
    }
}
