<?php
if (!defined('ABSPATH')) exit;
$brand = WANW_Settings::brand();
$lic = WANW_Settings::license();
$hb = $lic ? WANW_Api::heartbeat($lic) : null;
?>
<div class="wrap">
    <h1>WA Notifier — Dashboard</h1>
    <?php if (!$lic): ?>
        <div class="notice notice-warning"><p>Plugin is not activated yet.
            <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=wanw-wizard')); ?>">Run Setup Wizard</a>
        </p></div>
    <?php else: ?>
        <table class="widefat striped wanw-card">
            <tbody>
                <tr><th>License</th><td><code><?php echo esc_html($lic); ?></code></td></tr>
                <tr><th>Brand</th><td><?php echo esc_html($brand['name'] ?? '—'); ?></td></tr>
                <tr><th>Device</th><td><?php echo esc_html(WANW_Settings::device() ?: '—'); ?></td></tr>
                <tr><th>Heartbeat</th><td><?php echo !empty($hb['ok']) ? '<span style="color:green">OK ('.esc_html($hb['status']).')</span>' : '<span style="color:red">'.esc_html($hb['error'] ?? 'failed').'</span>'; ?></td></tr>
                <tr><th>API Base</th><td><code><?php echo esc_html(WANW_Settings::api_base()); ?></code></td></tr>
            </tbody>
        </table>
        <p>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wanw-woo')); ?>">WooCommerce Config</a>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wanw-admin')); ?>">Admin Config</a>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wanw-test')); ?>">Test</a>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wanw-license')); ?>">Change License</a>
        </p>
    <?php endif; ?>
</div>
